# Landing Page Project

## Table of Contents

* [Instructions](#instructions)

## Instructions

The starter project has some HTML and CSS styling to display a static version of the Landing Page project. You'll need to convert this project from a static project to an interactive one. This will require modifying the HTML and CSS files, but primarily the JavaScript file.

To get started, open `js/app.js` and start building out the app's functionality

For specific, detailed instructions, look at the project instructions in the Udacity Classroom.
-----------------------------------------------------------------------------------------------
about the project :-

Project name Tourist places in Egypt

Introdaction
    I this project you can The Most puplar Tourist places in egypt and a nav menu that help you to scroll and jump into the page

In the project I use some Image from Google to help you make sense for what we descusion


language 
    -HTML
    -CSS
    -JavaScript
    -DOM

Usability 
    All features are usable across modern desktop, tablet, and phone browsers.

Styling
    Styling has been added for active states.
    
HTML Structure
    There are at least 5 sections that have been added to the page.
    
Achnowledgments
    https://udacity.com/
    https://ar.wikipedia.org/
    
My Name : Mohamed Samir Salem Mohamed
